app.get('/comments', (request, response) => {
  db.all(`SELECT rowid, description FROM comments`, [], (err, rows) => {
    if (err) {
      response.status(400).send(err);
    }else{
      response.send(rows);
    }
  });
});