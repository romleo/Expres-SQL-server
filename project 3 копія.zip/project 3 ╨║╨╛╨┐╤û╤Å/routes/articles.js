
const tokenUtils = require('./auth/token-utils');
const articlesDac = require('../dac/articles');

app.get('/articles', (request, response) => {
  db.query('SELECT * FROM articles', function(err, rows, fields) {
    if (err) {
      response.status(400).send(err);
    } else {
      response.send(rows);
    }
  });
});

app.delete('/articles', (request, response) => {
  const data = request.query;
  if (data.id) {
    db.query(`DELETE FROM articles WHERE id=?`,
        [data.id], function(err, rows, fields) {
          if (err) {
            response.status(400).send(
                {error: 'Unable to delete article ' + err});
          } else {
            response.send({status: 'OK'});
          }
        });
  }
});

app.post('/articles', (request, response) => {
  const data = request.query;
  if (data.title && data.body) {
    if (data.id) {
      tokenUtils.getDecodedToken(request)
          .then((decoded) => articlesDac.getArticles(
              data.id, decoded.id, data.title, data.body))
          .catch((error) => response.status(error.status).send(error.message));
    } else {
      tokenUtils.getDecodedToken(request)
          .then((decoded) => {
            db.query(
                `INSERT INTO articles VALUES(?, ?, ?, ?, ?)`,
                [null, data.title, data.body, new Date(), decoded.id],
                function(err, rows, fields) {
                  if (err) {
                    response.status(400).send({error: 'Unable to save new article'});
                  } else {
                    response.send({status: 'OK'});
                  }
                });
          })
          .catch((error) => response.status(error.status).send(error.message));
    }
  } else {
    response.status(400).send({error: 'title and body are required fields'});
  }
});
