module.exports = {
  'secret': 'supersecret',
};
