const ResponseError = require('../routes/auth/response-error');

const updateArticle = (id, decodedId, title, body) => {
  const promise = new Promise((resolve, reject) => {
    db.query('SELECT * FROM articles where id=?', [id], function(err, rows, fields) {
      if (err) {
        reject(new ResponseError(err, 400));
      } else {
        if (rows[0].user_id === decodedId) {
          db.query(`UPDATE articles SET title = ?, body = ? WHERE id = ?`,
              [title, body, id], function(err, rows, fields) {
                if (err) {
                  reject(new ResponseError('Unable to update article ' + err, 400));
                } else {
                  resolve({status: 'OK'});
                }
              });
        } else {
          reject(new ResponseError(
              'User doesn\'t have permiossions to edit this article.', 400));
        }
      }
    });
  });
  return promise;
};


module.exports.updateArticle = updateArticle;
